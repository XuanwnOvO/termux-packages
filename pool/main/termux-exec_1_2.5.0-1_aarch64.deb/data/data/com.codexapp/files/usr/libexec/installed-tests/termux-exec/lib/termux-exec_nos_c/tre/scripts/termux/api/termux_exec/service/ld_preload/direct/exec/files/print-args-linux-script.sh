#!/data/data/com.codexapp/files/usr/bin/sh

echo "$@"
